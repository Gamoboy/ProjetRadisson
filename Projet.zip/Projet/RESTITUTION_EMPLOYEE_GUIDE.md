# Guide : Page de Restitution du Matériel par Employé

## 📋 Vue d'ensemble

Une nouvelle page a été ajoutée au système de gestion du matériel Radisson Hotel pour faciliter le processus de restitution du matériel lors du départ des employés.

## 🎯 Fonctionnalités

### 1. Sélection de l'Employé
- Menu déroulant permettant de sélectionner n'importe quel employé (actif ou parti)
- Affichage des informations de l'employé : nom, département, poste, statut

### 2. Vue à Deux Colonnes

#### Colonne Gauche : Matériel Donné
- Affiche tous les matériels assignés à l'employé qui n'ont pas encore été restitués
- Pour chaque matériel :
  - Type, marque, modèle
  - Numéro de série
  - Date d'assignation
  - État actuel
  - **Champs RH** :
    - Sélection de l'état à la restitution (Neuf, Très bon, Bon, Correct, Usagé, Endommagé, Perdu)
    - Zone de texte pour les observations
  - Bouton "Marquer comme restitué"

#### Colonne Droite : Matériel Restitué
- Affiche tous les matériels qui ont été marqués comme restitués
- Pour chaque matériel :
  - Type, marque, modèle
  - Numéro de série
  - État à la restitution
  - Date de restitution

### 3. Section Signatures

#### Signature Employé
- Nom pré-rempli avec les informations de l'employé
- Date (modifiable)
- Zone de signature numérique (l'employé tape son nom)

#### Signature Service RH
- Nom du responsable RH (à saisir)
- Date (modifiable)
- Zone de signature numérique (le RH tape son nom)

### 4. Texte d'Engagement
Texte légal affiché avant les signatures :
> "Je confirme avoir restitué l'intégralité du matériel mentionné ci-dessus au service RH de l'établissement Radisson Hotel dans l'état indiqué."

## 🔄 Workflow

1. **Sélection** : Le RH sélectionne l'employé qui part
2. **Restitution** : Pour chaque matériel à restituer :
   - Sélectionner l'état du matériel
   - Ajouter des observations si nécessaire
   - Cliquer sur "Marquer comme restitué"
   - Le matériel se déplace automatiquement dans la colonne de droite
3. **Signatures** : Une fois tous les matériels restitués :
   - L'employé signe numériquement
   - Le responsable RH signe également
4. **Finalisation** : Cliquer sur "Finaliser la restitution"

## 🛣️ Accès à la Page

- **URL** : `/employee-restitution`
- **Navigation** : Cliquer sur "Restitution Employé" dans le menu latéral gauche
- **Icône** : 📋 (ClipboardCheck)

## 🎨 Design

- **Colonne gauche** : Fond orange clair (matériel en attente)
- **Colonne droite** : Fond vert clair (matériel restitué)
- **Section signatures** : Fond bleu clair
- **Responsive** : S'adapte aux écrans mobiles et desktop

## 🔌 Intégration Backend

La page utilise les endpoints API existants :
- `GET /api/employees` : Récupérer la liste des employés
- `GET /api/employees/:id` : Récupérer les détails d'un employé
- `PUT /api/materials/:id` : Mettre à jour un matériel (marquer comme restitué)

## ✅ Validations

- Tous les matériels doivent être restitués avant de pouvoir finaliser
- Les signatures de l'employé et du RH sont obligatoires
- Le nom du responsable RH est obligatoire
- Un message d'erreur s'affiche si on tente de finaliser avec des matériels non restitués

## 📱 Notifications

Des notifications toast s'affichent pour :
- ✅ Succès de la restitution d'un matériel
- ✅ Finalisation complète du processus
- ❌ Erreurs (matériel non restitué, signatures manquantes, etc.)

## 🔧 Fichiers Modifiés

1. **Nouveau composant** : `/app/frontend/src/components/EmployeeRestitutionPage.jsx`
2. **Routing** : `/app/frontend/src/App.js` (ajout de la route)
3. **Navigation** : `/app/frontend/src/components/Layout.jsx` (ajout du lien)

## 📝 Notes Importantes

- La page est accessible pour tous les employés (actifs ou partis)
- Le processus de restitution peut être effectué en plusieurs fois
- Les données sont sauvegardées en temps réel dans MongoDB
- La page utilise les composants UI existants (shadcn/ui) pour la cohérence du design

## 🎯 Cas d'Usage Typique

**Scénario** : Sophie Bernard (Gouvernante) quitte l'hôtel

1. RH sélectionne "Sophie Bernard" dans le menu déroulant
2. La page affiche sa tablette Samsung Galaxy Tab A8
3. RH inspecte physiquement la tablette
4. RH sélectionne l'état "Bon" dans le menu déroulant
5. RH ajoute une note : "Légères rayures sur l'écran, fonctionnement OK"
6. RH clique sur "Marquer comme restitué"
7. La tablette apparaît maintenant dans la colonne de droite
8. Sophie signe numériquement en tapant son nom
9. Le responsable RH (ex: "Jean Martin") signe également
10. RH clique sur "Finaliser la restitution"
11. Message de succès : "Restitution finalisée" 
12. Le formulaire se réinitialise

---

**Développé avec Emergent** 🚀
