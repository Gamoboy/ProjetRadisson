import React, { useState, useEffect } from "react";
import { UserPlus, UserMinus, Search, Filter, Calendar, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useToast } from "../hooks/use-toast";
import { employeeAPI } from "../services/api";

const EmployeeFlow = () => {
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPeriod, setFilterPeriod] = useState("month");
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const data = await employeeAPI.getAll();
      setEmployees(data);
    } catch (error) {
      console.error('Error loading employees:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les employés",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Filter employees based on search and filters
  const filteredEmployees = employees.filter(emp => {
    const matchesSearch = emp.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.department.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || emp.status === filterStatus;
    
    // Filter by period (for demonstration)
    let matchesPeriod = true;
    if (filterPeriod === "week") {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      matchesPeriod = new Date(emp.startDate) >= weekAgo;
    } else if (filterPeriod === "month") {
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      matchesPeriod = new Date(emp.startDate) >= monthAgo;
    }
    
    return matchesSearch && matchesStatus && matchesPeriod;
  });

  // Calculate statistics
  const stats = {
    total: employees.length,
    active: employees.filter(emp => emp.status === "active").length,
    departed: employees.filter(emp => emp.status === "departed").length,
    newThisMonth: employees.filter(emp => {
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      return new Date(emp.startDate) >= monthAgo && emp.status === "active";
    }).length
  };

  const StatsCard = ({ title, value, icon: Icon, color, subtitle }) => (
    <Card className="transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="pt-6">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-full ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-600">{title}</p>
            <p className="text-2xl font-bold text-slate-900">{value}</p>
            {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const EmployeeRow = ({ employee }) => {
    const isRecentArrival = () => {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return new Date(employee.startDate) >= weekAgo && employee.status === "active";
    };

    const isRecentDeparture = () => {
      if (!employee.endDate || employee.status === "active") return false;
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return new Date(employee.endDate) >= weekAgo;
    };

    return (
      <tr className={`border-b border-slate-100 hover:bg-slate-50 transition-colors duration-150 ${
        isRecentArrival() ? 'bg-green-50' : isRecentDeparture() ? 'bg-red-50' : ''
      }`}>
        <td className="py-4 px-3">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${
              isRecentArrival() ? 'bg-green-500' : 
              isRecentDeparture() ? 'bg-red-500' : 
              employee.status === 'active' ? 'bg-blue-500' : 'bg-slate-400'
            }`}></div>
            <div>
              <div className="font-medium text-slate-900">
                {employee.firstName} {employee.lastName}
              </div>
              <div className="text-sm text-slate-500">{employee.position}</div>
            </div>
          </div>
        </td>
        <td className="py-4 px-3 text-slate-600">{employee.department}</td>
        <td className="py-4 px-3 text-slate-600">
          {new Date(employee.startDate).toLocaleDateString("fr-FR")}
        </td>
        <td className="py-4 px-3 text-slate-600">
          {employee.endDate ? new Date(employee.endDate).toLocaleDateString("fr-FR") : "-"}
        </td>
        <td className="py-4 px-3">
          <div className="flex items-center gap-2">
            <Badge 
              variant={employee.status === "active" ? "default" : "secondary"}
              className={`${
                employee.status === "active" 
                  ? "bg-green-100 text-green-800" 
                  : "bg-red-100 text-red-800"
              }`}
            >
              {employee.status === "active" ? "Actif" : "Parti"}
            </Badge>
            {isRecentArrival() && (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Nouveau
              </Badge>
            )}
            {isRecentDeparture() && (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                Récent
              </Badge>
            )}
          </div>
        </td>
        <td className="py-4 px-3">
          <div className="text-sm">
            {employee.materials?.filter(mat => !mat.returned).length || 0} équipement(s)
          </div>
        </td>
      </tr>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Clock className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Chargement...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Flux des collaborateurs</h1>
          <p className="text-slate-600 mt-1">
            Suivi des entrées et sorties des employés
          </p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-green-600 hover:bg-green-700" onClick={() => window.location.href = '/employee/new'}>
            <UserPlus className="h-4 w-4 mr-2" />
            Entrée collaborateur
          </Button>
          <Button variant="outline" className="text-red-600 border-red-200 hover:bg-red-50">
            <UserMinus className="h-4 w-4 mr-2" />
            Sortie collaborateur
          </Button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total employés"
          value={stats.total}
          icon={TrendingUp}
          color="bg-blue-600"
          subtitle="Tous statuts confondus"
        />
        <StatsCard
          title="Employés actifs"
          value={stats.active}
          icon={UserPlus}
          color="bg-green-600"
          subtitle="Actuellement en poste"
        />
        <StatsCard
          title="Départs"
          value={stats.departed}
          icon={UserMinus}
          color="bg-red-600"
          subtitle="Employés partis"
        />
        <StatsCard
          title="Nouvelles arrivées"
          value={stats.newThisMonth}
          icon={Calendar}
          color="bg-purple-600"
          subtitle="Ce mois-ci"
        />
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Rechercher un employé..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous statuts</SelectItem>
                  <SelectItem value="active">Actifs</SelectItem>
                  <SelectItem value="departed">Partis</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={filterPeriod} onValueChange={setFilterPeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toute période</SelectItem>
                  <SelectItem value="week">Cette semaine</SelectItem>
                  <SelectItem value="month">Ce mois</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employee List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl text-slate-900">
            Historique des mouvements ({filteredEmployees.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-3 font-medium text-slate-600">Employé</th>
                  <th className="text-left py-3 px-3 font-medium text-slate-600">Département</th>
                  <th className="text-left py-3 px-3 font-medium text-slate-600">Entrée</th>
                  <th className="text-left py-3 px-3 font-medium text-slate-600">Sortie</th>
                  <th className="text-left py-3 px-3 font-medium text-slate-600">Statut</th>
                  <th className="text-left py-3 px-3 font-medium text-slate-600">Matériel</th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((employee) => (
                  <EmployeeRow key={employee.id} employee={employee} />
                ))}
              </tbody>
            </table>
          </div>
          
          {filteredEmployees.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              Aucun employé trouvé avec les critères sélectionnés
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default EmployeeFlow;