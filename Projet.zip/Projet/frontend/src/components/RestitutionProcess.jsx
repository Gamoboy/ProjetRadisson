import React, { useState, useEffect } from "react";
import { AlertTriangle, CheckCircle, Clock, Package, User, Loader2, Euro, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { useToast } from "../hooks/use-toast";
import { employeeAPI, materialAPI } from "../services/api";
import MaterialCostCalculator from "./MaterialCostCalculator";
import HRSignatureSection from "./HRSignatureSection";

const RestitutionProcess = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const data = await employeeAPI.getAll();
      setEmployees(data);
    } catch (error) {
      console.error('Error loading employees:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les employés",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Employees who have left but still have unreturned materials
  const pendingRestitutions = employees.filter(emp => 
    emp.status === "departed" && emp.materials?.some(mat => !mat.returned)
  );

  // Recent departures (last 30 days) with materials to return
  const recentDepartures = employees.filter(emp => {
    if (emp.status !== "departed" || !emp.endDate) return false;
    const endDate = new Date(emp.endDate);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return endDate >= thirtyDaysAgo && emp.materials?.some(mat => !mat.returned);
  });

  const handleMaterialReturn = async (materialId) => {
    try {
      await materialAPI.update(materialId, { 
        returned: true, 
        returnedDate: new Date().toISOString().split('T')[0] 
      });
      
      // Reload employees to get updated data
      await loadEmployees();

      toast({
        title: "Matériel restitué",
        description: "Le matériel a été marqué comme restitué"
      });
    } catch (error) {
      console.error('Error returning material:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la restitution",
        variant: "destructive"
      });
    }
  };

  const handleCompleteRestitution = (employee) => {
    const unreturned = employee.materials?.filter(mat => !mat.returned) || [];
    
    if (unreturned.length > 0) {
      toast({
        title: "Restitution incomplète",
        description: `Il reste ${unreturned.length} équipement(s) à restituer`,
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Restitution terminée",
      description: "Tous les équipements ont été restitués. Fiche retournée au service RH."
    });
  };

  const RestitutionCard = ({ employee, isUrgent = false }) => {
    const [showHRSignature, setShowHRSignature] = useState(false);
    const unreturnedMaterials = employee.materials?.filter(mat => !mat.returned) || [];
    const returnedMaterials = employee.materials?.filter(mat => mat.returned) || [];

    return (
      <Card className={`${isUrgent ? "border-red-200 bg-red-50" : ""} transition-all duration-200 hover:shadow-lg`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg text-slate-900 flex items-center gap-2">
                <User className="h-5 w-5" />
                {employee.firstName} {employee.lastName}
                {isUrgent && <AlertTriangle className="h-4 w-4 text-red-500" />}
              </CardTitle>
              <p className="text-slate-600">{employee.department} - {employee.position}</p>
              <p className="text-sm text-slate-500">
                Départ: {employee.endDate ? new Date(employee.endDate).toLocaleDateString("fr-FR") : "Non définie"}
              </p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <Badge variant={isUrgent ? "destructive" : "secondary"}>
                {unreturnedMaterials.length} à restituer
              </Badge>
              {returnedMaterials.length > 0 && (
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  {returnedMaterials.length} restitué(s)
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isUrgent && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                Restitution urgente requise - Employé parti depuis plus de 7 jours
              </AlertDescription>
            </Alert>
          )}

          {unreturnedMaterials.length > 0 && (
            <div className="mb-4">
              <h4 className="font-medium text-slate-900 mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-500" />
                Matériel à restituer
              </h4>
              <div className="space-y-2">
                {unreturnedMaterials.map((material) => (
                  <div 
                    key={material.materialId}
                    className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Package className="h-4 w-4 text-slate-400" />
                        <span className="font-medium text-slate-900">{material.type}</span>
                        <Badge variant="secondary">{material.condition}</Badge>
                      </div>
                      <div className="text-sm text-slate-600">
                        {material.brand} {material.model} - S/N: {material.serialNumber}
                      </div>
                      <div className="text-xs text-slate-500">
                        Assigné le: {new Date(material.assignedDate).toLocaleDateString("fr-FR")}
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleMaterialReturn(material.materialId)}
                      className="text-green-600 border-green-200 hover:bg-green-50"
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Restituer
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {returnedMaterials.length > 0 && (
            <div className="mb-4">
              <h4 className="font-medium text-slate-900 mb-3 flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Matériel restitué
              </h4>
              <div className="space-y-2">
                {returnedMaterials.map((material) => (
                  <div 
                    key={material.materialId}
                    className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-slate-900">{material.type}</span>
                      </div>
                      <div className="text-sm text-slate-600">
                        {material.brand} {material.model} - S/N: {material.serialNumber}
                      </div>
                      <div className="text-xs text-green-600">
                        Restitué le: {material.returnedDate ? new Date(material.returnedDate).toLocaleDateString("fr-FR") : ""}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
            <Button
              variant="outline"
              onClick={() => handleCompleteRestitution(employee)}
              disabled={unreturnedMaterials.length > 0}
            >
              Finaliser la restitution
            </Button>
            
            {unreturnedMaterials.length === 0 && !showHRSignature && (
              <Button
                onClick={() => setShowHRSignature(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <FileText className="h-4 w-4 mr-2" />
                Signature RH
              </Button>
            )}
            
            <Badge 
              variant={unreturnedMaterials.length === 0 ? "default" : "secondary"}
              className={unreturnedMaterials.length === 0 ? "bg-green-100 text-green-800" : ""}
            >
              {unreturnedMaterials.length === 0 ? "Terminé" : "En cours"}
            </Badge>
          </div>
          
          {/* HR Signature Section */}
          {showHRSignature && unreturnedMaterials.length === 0 && (
            <div className="mt-6 pt-6 border-t border-slate-200">
              <HRSignatureSection 
                employee={employee}
                materials={employee.materials}
                mode="restitution"
                onSignatureComplete={(data) => {
                  console.log("HR Restitution signature data:", data);
                  setShowHRSignature(false);
                  toast({
                    title: "Restitution finalisée",
                    description: "Document signé et archivé. Fiche retournée au service RH."
                  });
                }}
              />
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Chargement des restitutions...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Processus de restitution</h1>
        <p className="text-slate-600 mt-1">
          Gestion des restitutions de matériel pour les départs d'employés
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-red-100 rounded-full">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-600">Restitutions en attente</p>
                <p className="text-2xl font-bold text-slate-900">{pendingRestitutions.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-orange-100 rounded-full">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-600">Départs récents</p>
                <p className="text-2xl font-bold text-slate-900">{recentDepartures.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-full">
                <Package className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-600">Équipements à récupérer</p>
                <p className="text-2xl font-bold text-slate-900">
                  {pendingRestitutions.reduce((sum, emp) => 
                    sum + (emp.materials?.filter(mat => !mat.returned).length || 0), 0
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Urgent Restitutions */}
      {recentDepartures.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Restitutions urgentes
          </h2>
          <div className="space-y-4">
            {recentDepartures.map((employee) => (
              <RestitutionCard 
                key={employee.id} 
                employee={employee} 
                isUrgent={true}
              />
            ))}
          </div>
        </div>
      )}

      {/* All Pending Restitutions */}
      {pendingRestitutions.length > 0 ? (
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-4">
            Toutes les restitutions en attente
          </h2>
          <div className="space-y-4">
            {pendingRestitutions.map((employee) => (
              <RestitutionCard 
                key={employee.id} 
                employee={employee}
                isUrgent={recentDepartures.some(emp => emp.id === employee.id)}
              />
            ))}
          </div>
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              Aucune restitution en attente
            </h3>
            <p className="text-slate-600">
              Tous les équipements ont été restitués avec succès
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RestitutionProcess;