import React from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "../lib/utils";
import { 
  Home, 
  UserPlus, 
  Package, 
  RotateCcw,
  Building2,
  Menu,
  User,
  Users,
  ClipboardCheck
} from "lucide-react";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";

const Layout = ({ children }) => {
  const location = useLocation();

  const navigation = [
    { name: "Tableau de bord", href: "/", icon: Home },
    { name: "Nouvel employé", href: "/employee/new", icon: UserPlus },
    { name: "Flux collaborateurs", href: "/employee-flow", icon: Users },
    { name: "Gestion matériel", href: "/material-management", icon: Package },
    { name: "Restitutions", href: "/restitution", icon: RotateCcw },
    { name: "Restitution Employé", href: "/employee-restitution", icon: ClipboardCheck },
    { name: "Mon profil", href: "/profile", icon: User },
  ];

  const NavigationItems = ({ isMobile = false }) => (
    <nav className={cn("space-y-2", isMobile && "mt-8")}>
      {navigation.map((item) => {
        const Icon = item.icon;
        const isActive = location.pathname === item.href;
        return (
          <Link
            key={item.name}
            to={item.href}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all duration-200 hover:bg-slate-100",
              isActive && "bg-blue-600 text-white hover:bg-blue-700",
              !isActive && "text-slate-600 hover:text-slate-900"
            )}
          >
            <Icon className="h-5 w-5" />
            {item.name}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Desktop Sidebar */}
      <div className="hidden md:fixed md:inset-y-0 md:flex md:w-72 md:flex-col">
        <div className="flex flex-col flex-grow pt-8 bg-white shadow-xl border-r border-slate-200">
          <div className="flex items-center flex-shrink-0 px-6 mb-8">
            <img 
              src="https://images.seeklogo.com/logo-png/35/2/radisson-hotel-group-logo-png_seeklogo-358731.png" 
              alt="Radisson Hotel Group" 
              className="h-8 w-auto mr-3"
            />
            <div>
              <h1 className="text-xl font-bold text-slate-900">Radisson Hotel</h1>
              <p className="text-sm text-slate-500">Gestion Matériel IT</p>
            </div>
          </div>
          <div className="flex-1 px-4 pb-4">
            <NavigationItems />
          </div>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden bg-white shadow-sm border-b border-slate-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <img 
              src="https://images.seeklogo.com/logo-png/35/2/radisson-hotel-group-logo-png_seeklogo-358731.png" 
              alt="Radisson Hotel Group" 
              className="h-6 w-auto mr-2"
            />
            <h1 className="text-lg font-bold text-slate-900">Radisson</h1>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72">
              <div className="flex items-center mb-6">
                <img 
                  src="https://images.seeklogo.com/logo-png/35/2/radisson-hotel-group-logo-png_seeklogo-358731.png" 
                  alt="Radisson Hotel Group" 
                  className="h-6 w-auto mr-2"
                />
                <div>
                  <h1 className="text-lg font-bold text-slate-900">Radisson Hotel</h1>
                  <p className="text-xs text-slate-500">Gestion Matériel IT</p>
                </div>
              </div>
              <NavigationItems isMobile />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <div className="md:pl-72">
        <main className="py-6 px-4 md:px-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;