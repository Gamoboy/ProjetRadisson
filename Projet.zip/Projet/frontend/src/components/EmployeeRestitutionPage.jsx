import React, { useState, useEffect } from "react";
import { User, Package, CheckCircle, ArrowRight, Loader2, AlertCircle, PenTool, FileCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Alert, AlertDescription } from "./ui/alert";
import { useToast } from "../hooks/use-toast";
import { employeeAPI, materialAPI } from "../services/api";
import SignatureCanvas from "./SignatureCanvas";

const EmployeeRestitutionPage = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [returnStates, setReturnStates] = useState({});
  const [signatures, setSignatures] = useState({
    employeeSignature: "",
    employeeDate: new Date().toISOString().split('T')[0],
    hrName: "",
    hrSignature: "",
    hrDate: new Date().toISOString().split('T')[0]
  });
  const { toast } = useToast();

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const data = await employeeAPI.getAll();
      setEmployees(data);
    } catch (error) {
      console.error('Error loading employees:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les employés",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEmployeeSelect = (employeeId) => {
    const employee = employees.find(emp => emp.id === employeeId);
    setSelectedEmployee(employee);
    
    // Initialize return states for all materials
    if (employee && employee.materials) {
      const initialStates = {};
      employee.materials.forEach(mat => {
        initialStates[mat.materialId] = {
          condition: mat.condition || "Bon",
          notes: ""
        };
      });
      setReturnStates(initialStates);
    }
    
    // Reset signatures
    setSignatures({
      employeeSignature: "",
      employeeDate: new Date().toISOString().split('T')[0],
      hrName: "",
      hrSignature: "",
      hrDate: new Date().toISOString().split('T')[0]
    });
  };

  const handleReturnMaterial = async (materialId) => {
    if (!returnStates[materialId]) {
      toast({
        title: "Erreur",
        description: "Veuillez renseigner l'état du matériel",
        variant: "destructive"
      });
      return;
    }

    try {
      await materialAPI.update(materialId, {
        returned: true,
        returnedDate: new Date().toISOString().split('T')[0],
        condition: returnStates[materialId].condition
      });

      // Reload employee data
      const updatedEmployee = await employeeAPI.getById(selectedEmployee.id);
      setSelectedEmployee(updatedEmployee);

      toast({
        title: "Matériel restitué",
        description: "Le matériel a été marqué comme restitué avec succès"
      });
    } catch (error) {
      console.error('Error returning material:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la restitution du matériel",
        variant: "destructive"
      });
    }
  };

  const handleConditionChange = (materialId, condition) => {
    setReturnStates(prev => ({
      ...prev,
      [materialId]: {
        ...prev[materialId],
        condition
      }
    }));
  };

  const handleNotesChange = (materialId, notes) => {
    setReturnStates(prev => ({
      ...prev,
      [materialId]: {
        ...prev[materialId],
        notes
      }
    }));
  };

  const handleSignatureChange = (field, value) => {
    setSignatures(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCompleteRestitution = () => {
    const unreturnedMaterials = selectedEmployee?.materials?.filter(mat => !mat.returned) || [];
    
    if (unreturnedMaterials.length > 0) {
      toast({
        title: "Restitution incomplète",
        description: `Il reste ${unreturnedMaterials.length} équipement(s) à restituer`,
        variant: "destructive"
      });
      return;
    }

    if (!signatures.employeeSignature || !signatures.hrSignature || !signatures.hrName) {
      toast({
        title: "Signatures manquantes",
        description: "Les signatures de l'employé et du RH sont requises",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Restitution finalisée",
      description: "Toutes les signatures ont été collectées. Document archivé avec succès."
    });

    // Reset after completion
    setSelectedEmployee(null);
    setReturnStates({});
    setSignatures({
      employeeSignature: "",
      employeeDate: new Date().toISOString().split('T')[0],
      hrName: "",
      hrSignature: "",
      hrDate: new Date().toISOString().split('T')[0]
    });
  };

  const unreturnedMaterials = selectedEmployee?.materials?.filter(mat => !mat.returned) || [];
  const returnedMaterials = selectedEmployee?.materials?.filter(mat => mat.returned) || [];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Chargement...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Restitution du Matériel</h1>
        <p className="text-slate-600 mt-1">
          Processus de restitution du matériel lors du départ d'un employé
        </p>
      </div>

      {/* Employee Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Sélection de l'employé</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="employee-select">Choisir un employé</Label>
              <select
                id="employee-select"
                value={selectedEmployee?.id || ""}
                onChange={(e) => handleEmployeeSelect(e.target.value)}
                className="w-full mt-1 p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">-- Sélectionner un employé --</option>
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.firstName} {emp.lastName} - {emp.department} ({emp.status === "active" ? "Actif" : "Parti"})
                  </option>
                ))}
              </select>
            </div>

            {selectedEmployee && (
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-center gap-3 mb-3">
                  <User className="h-5 w-5 text-blue-600" />
                  <h3 className="font-semibold text-blue-900">
                    {selectedEmployee.firstName} {selectedEmployee.lastName}
                  </h3>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-slate-700">ID:</span>
                    <span className="ml-2 text-slate-600">{selectedEmployee.employeeId}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-700">Département:</span>
                    <span className="ml-2 text-slate-600">{selectedEmployee.department}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-700">Poste:</span>
                    <span className="ml-2 text-slate-600">{selectedEmployee.position}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-700">Statut:</span>
                    <Badge variant={selectedEmployee.status === "active" ? "default" : "secondary"} className="ml-2">
                      {selectedEmployee.status === "active" ? "Actif" : "Parti"}
                    </Badge>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Materials View - Two Columns */}
      {selectedEmployee && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column - Material Given */}
            <Card className="border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="text-lg text-orange-900 flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Matériel donné à l'employé
                  <Badge variant="secondary" className="ml-2">
                    {unreturnedMaterials.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {unreturnedMaterials.length > 0 ? (
                  <div className="space-y-3">
                    {unreturnedMaterials.map((material) => (
                      <div 
                        key={material.materialId}
                        className="bg-white p-4 rounded-lg border border-orange-200 space-y-3"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Package className="h-4 w-4 text-slate-400" />
                              <span className="font-medium text-slate-900">{material.type}</span>
                            </div>
                            <div className="text-sm text-slate-600">
                              {material.brand} {material.model}
                            </div>
                            <div className="text-xs text-slate-500">
                              S/N: {material.serialNumber}
                            </div>
                            <div className="text-xs text-slate-500">
                              Assigné le: {new Date(material.assignedDate).toLocaleDateString("fr-FR")}
                            </div>
                          </div>
                          <Badge variant="outline">{material.condition}</Badge>
                        </div>

                        {/* Condition and Notes for Return */}
                        <div className="space-y-2 pt-2 border-t border-slate-200">
                          <div>
                            <Label className="text-xs">État à la restitution</Label>
                            <select
                              value={returnStates[material.materialId]?.condition || "Bon"}
                              onChange={(e) => handleConditionChange(material.materialId, e.target.value)}
                              className="w-full mt-1 text-sm p-2 border border-slate-300 rounded"
                            >
                              <option value="Neuf">Neuf</option>
                              <option value="Très bon">Très bon</option>
                              <option value="Bon">Bon</option>
                              <option value="Correct">Correct</option>
                              <option value="Usagé">Usagé</option>
                              <option value="Endommagé">Endommagé</option>
                              <option value="Perdu">Perdu</option>
                            </select>
                          </div>
                          <div>
                            <Label className="text-xs">Observations</Label>
                            <Input
                              placeholder="Notes sur l'état du matériel..."
                              value={returnStates[material.materialId]?.notes || ""}
                              onChange={(e) => handleNotesChange(material.materialId, e.target.value)}
                              className="text-sm"
                            />
                          </div>
                        </div>

                        <Button
                          onClick={() => handleReturnMaterial(material.materialId)}
                          className="w-full bg-green-600 hover:bg-green-700"
                          size="sm"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Marquer comme restitué
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    <AlertCircle className="h-12 w-12 mx-auto mb-2 text-slate-300" />
                    <p>Aucun matériel en attente de restitution</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Right Column - Material Returned */}
            <Card className="border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="text-lg text-green-900 flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Matériel restitué
                  <Badge variant="secondary" className="ml-2">
                    {returnedMaterials.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {returnedMaterials.length > 0 ? (
                  <div className="space-y-3">
                    {returnedMaterials.map((material) => (
                      <div 
                        key={material.materialId}
                        className="bg-white p-4 rounded-lg border border-green-200"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <CheckCircle className="h-4 w-4 text-green-600" />
                              <span className="font-medium text-slate-900">{material.type}</span>
                            </div>
                            <div className="text-sm text-slate-600">
                              {material.brand} {material.model}
                            </div>
                            <div className="text-xs text-slate-500">
                              S/N: {material.serialNumber}
                            </div>
                          </div>
                          <Badge className="bg-green-100 text-green-800 border-green-200">
                            {material.condition}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-green-700 pt-2 border-t border-green-100">
                          <div>
                            <span className="font-medium">Restitué le:</span>
                            <span className="ml-1">{material.returnedDate ? new Date(material.returnedDate).toLocaleDateString("fr-FR") : "-"}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    <Package className="h-12 w-12 mx-auto mb-2 text-slate-300" />
                    <p>Aucun matériel restitué pour le moment</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Signature Section */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-xl text-blue-900 flex items-center gap-2">
                <FileCheck className="h-6 w-6" />
                Signatures de restitution
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {unreturnedMaterials.length > 0 && (
                <Alert className="border-orange-200 bg-orange-50">
                  <AlertCircle className="h-4 w-4 text-orange-600" />
                  <AlertDescription className="text-orange-800">
                    Attention : Il reste {unreturnedMaterials.length} équipement(s) à restituer avant de finaliser les signatures.
                  </AlertDescription>
                </Alert>
              )}

              {/* Engagement Text */}
              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <h4 className="font-semibold text-amber-900 mb-2">Engagement de l'employé :</h4>
                <p className="text-sm text-amber-800">
                  Je confirme avoir restitué l'intégralité du matériel mentionné ci-dessus au service RH de l'établissement Radisson Hotel dans l'état indiqué.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Employee Signature */}
                <div className="bg-white p-4 rounded-lg border border-blue-200">
                  <h3 className="font-semibold text-blue-900 mb-4 flex items-center gap-2">
                    <PenTool className="h-4 w-4" />
                    Signature Employé
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <Label>Nom et prénom</Label>
                      <Input
                        value={`${selectedEmployee.firstName} ${selectedEmployee.lastName}`}
                        disabled
                        className="mt-1 bg-slate-100"
                      />
                    </div>
                    <div>
                      <Label htmlFor="employeeDate">Date</Label>
                      <Input
                        id="employeeDate"
                        type="date"
                        value={signatures.employeeDate}
                        onChange={(e) => handleSignatureChange("employeeDate", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="employeeSignature">Signature *</Label>
                      <div className="mt-1 border-2 border-dashed border-blue-300 rounded-lg p-4 bg-blue-25">
                        <Input
                          id="employeeSignature"
                          value={signatures.employeeSignature}
                          onChange={(e) => handleSignatureChange("employeeSignature", e.target.value)}
                          placeholder="L'employé tape son nom pour signer"
                          className="text-center font-serif text-lg"
                        />
                        <p className="text-xs text-blue-600 text-center mt-1">
                          Signature numérique employé
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* HR Signature */}
                <div className="bg-white p-4 rounded-lg border border-blue-200">
                  <h3 className="font-semibold text-blue-900 mb-4 flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Signature Service RH
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="hrName">Nom et prénom *</Label>
                      <Input
                        id="hrName"
                        value={signatures.hrName}
                        onChange={(e) => handleSignatureChange("hrName", e.target.value)}
                        placeholder="Nom complet du responsable RH"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="hrDate">Date</Label>
                      <Input
                        id="hrDate"
                        type="date"
                        value={signatures.hrDate}
                        onChange={(e) => handleSignatureChange("hrDate", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="hrSignature">Signature *</Label>
                      <div className="mt-1 border-2 border-dashed border-blue-300 rounded-lg p-4 bg-blue-25">
                        <Input
                          id="hrSignature"
                          value={signatures.hrSignature}
                          onChange={(e) => handleSignatureChange("hrSignature", e.target.value)}
                          placeholder="Tapez votre nom pour signer"
                          className="text-center font-serif text-lg"
                        />
                        <p className="text-xs text-blue-600 text-center mt-1">
                          Signature numérique RH
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Complete Button */}
              <div className="flex justify-end">
                <Button
                  onClick={handleCompleteRestitution}
                  disabled={unreturnedMaterials.length > 0 || !signatures.employeeSignature || !signatures.hrSignature || !signatures.hrName}
                  className="bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  <FileCheck className="h-5 w-5 mr-2" />
                  Finaliser la restitution
                </Button>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default EmployeeRestitutionPage;
