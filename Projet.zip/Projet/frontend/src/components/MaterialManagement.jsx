import React, { useState, useEffect } from "react";
import { Search, Plus, Package, AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Label } from "./ui/label";
import { useToast } from "../hooks/use-toast";
import { employeeAPI, materialAPI } from "../services/api";
import { mockMaterialTypes, mockConditions } from "../mock";

const MaterialManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const { toast } = useToast();

  const [newMaterial, setNewMaterial] = useState({
    type: "",
    brand: "",
    model: "",
    serialNumber: "",
    condition: "Neuf"
  });

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const data = await employeeAPI.getAll("active");
      setEmployees(data);
    } catch (error) {
      console.error('Error loading employees:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les employés",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredEmployees = employees.filter(emp =>
    emp.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddMaterial = async () => {
    if (!selectedEmployee || !newMaterial.type || !newMaterial.brand || !newMaterial.serialNumber) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    setAdding(true);
    try {
      await employeeAPI.addMaterial(selectedEmployee.id, newMaterial);
      
      // Reload employees to get updated data
      await loadEmployees();
      
      setIsAddModalOpen(false);
      setSelectedEmployee(null);
      setNewMaterial({
        type: "",
        brand: "",
        model: "",
        serialNumber: "",
        condition: "Neuf"
      });

      toast({
        title: "Succès",
        description: "Matériel ajouté avec succès"
      });
    } catch (error) {
      console.error('Error adding material:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de l'ajout du matériel",
        variant: "destructive"
      });
    } finally {
      setAdding(false);
    }
  };

  const handleReturnMaterial = async (materialId) => {
    try {
      await materialAPI.update(materialId, { 
        returned: true, 
        returnedDate: new Date().toISOString().split('T')[0] 
      });
      
      // Reload employees to get updated data
      await loadEmployees();

      toast({
        title: "Matériel restitué",
        description: "Le matériel a été marqué comme restitué"
      });
    } catch (error) {
      console.error('Error returning material:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la restitution",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Chargement des employés...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Gestion du matériel</h1>
          <p className="text-slate-600 mt-1">
            Mise à disposition et suivi du matériel informatique
          </p>
        </div>
        
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Ajouter du matériel
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Ajouter du matériel</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Employé</Label>
                <Select 
                  value={selectedEmployee?.id || ""} 
                  onValueChange={(value) => {
                    const emp = employees.find(e => e.id === value);
                    setSelectedEmployee(emp);
                  }}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Sélectionner un employé" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>
                        {emp.firstName} {emp.lastName} - {emp.department}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Type de matériel</Label>
                <Select 
                  value={newMaterial.type} 
                  onValueChange={(value) => setNewMaterial(prev => ({ ...prev, type: value }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockMaterialTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Marque</Label>
                <Input
                  value={newMaterial.brand}
                  onChange={(e) => setNewMaterial(prev => ({ ...prev, brand: e.target.value }))}
                  placeholder="Marque du matériel"
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label>Modèle</Label>
                <Input
                  value={newMaterial.model}
                  onChange={(e) => setNewMaterial(prev => ({ ...prev, model: e.target.value }))}
                  placeholder="Modèle"
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label>Numéro de série</Label>
                <Input
                  value={newMaterial.serialNumber}
                  onChange={(e) => setNewMaterial(prev => ({ ...prev, serialNumber: e.target.value }))}
                  placeholder="Numéro de série"
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label>État</Label>
                <Select 
                  value={newMaterial.condition} 
                  onValueChange={(value) => setNewMaterial(prev => ({ ...prev, condition: value }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {mockConditions.map(condition => (
                      <SelectItem key={condition} value={condition}>{condition}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setIsAddModalOpen(false)}
                  disabled={adding}
                >
                  Annuler
                </Button>
                <Button 
                  onClick={handleAddMaterial}
                  disabled={adding}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {adding ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Ajout...
                    </>
                  ) : (
                    "Ajouter"
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Rechercher un employé..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Employees Material List */}
      <div className="space-y-4">
        {filteredEmployees.map((employee) => (
          <Card key={employee.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg text-slate-900">
                    {employee.firstName} {employee.lastName}
                  </CardTitle>
                  <p className="text-slate-600">{employee.department} - {employee.position}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Package className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-600">
                    {employee.materials?.filter(mat => !mat.returned).length || 0} équipement(s)
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {!employee.materials || employee.materials.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <Package className="h-12 w-12 mx-auto mb-2 text-slate-300" />
                  <p>Aucun matériel assigné</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {employee.materials.map((material) => (
                    <div 
                      key={material.materialId}
                      className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium text-slate-900">{material.type}</span>
                          <Badge 
                            variant={material.returned ? "secondary" : "default"}
                            className={material.returned ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"}
                          >
                            {material.returned ? "Restitué" : material.condition}
                          </Badge>
                        </div>
                        <div className="text-sm text-slate-600 space-y-1">
                          <p>{material.brand} {material.model}</p>
                          <p>S/N: {material.serialNumber}</p>
                          <p>Assigné le: {new Date(material.assignedDate).toLocaleDateString("fr-FR")}</p>
                          {material.returned && material.returnedDate && (
                            <p className="text-green-600">
                              Restitué le: {new Date(material.returnedDate).toLocaleDateString("fr-FR")}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {!material.returned ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleReturnMaterial(material.materialId)}
                            className="text-green-600 border-green-200 hover:bg-green-50"
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Marquer restitué
                          </Button>
                        ) : (
                          <div className="flex items-center text-green-600 text-sm">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Restitué
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredEmployees.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">Aucun employé trouvé</h3>
            <p className="text-slate-600">
              Essayez de modifier votre recherche ou ajoutez de nouveaux employés
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MaterialManagement;