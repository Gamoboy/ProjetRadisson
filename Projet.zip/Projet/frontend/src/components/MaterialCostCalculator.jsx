import React, { useState, useEffect } from "react";
import { Calculator, AlertTriangle, Euro } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

const MaterialCostCalculator = ({ materials = [], onCostCalculated }) => {
  const [totalCost, setTotalCost] = useState(0);
  const [lostItems, setLostItems] = useState([]);

  // Prix de remplacement des badges et équipements spéciaux
  const replacementCosts = {
    "Cadenas": 5,
    "Pins Yes I Can": 5,
    "Name Tag": 10,
    "Badge Horaire": 10
  };

  useEffect(() => {
    calculateReplacementCost();
  }, [materials]);

  const calculateReplacementCost = () => {
    const lost = materials.filter(material => 
      material.condition === "Perdu" || material.condition === "Endommagé"
    );
    
    let cost = 0;
    const itemsWithCost = [];

    lost.forEach(item => {
      if (replacementCosts[item.type]) {
        cost += replacementCosts[item.type];
        itemsWithCost.push({
          ...item,
          replacementCost: replacementCosts[item.type]
        });
      }
    });

    setLostItems(itemsWithCost);
    setTotalCost(cost);
    
    if (onCostCalculated) {
      onCostCalculated(cost, itemsWithCost);
    }
  };

  if (lostItems.length === 0) {
    return null;
  }

  return (
    <Card className="border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="text-lg text-orange-900 flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Calcul des frais de remplacement
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {lostItems.map((item, index) => (
            <div 
              key={index}
              className="flex items-center justify-between p-3 bg-white border border-orange-200 rounded-lg"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <span className="font-medium text-slate-900">{item.type}</span>
                  <Badge variant="destructive">{item.condition}</Badge>
                </div>
                <div className="text-sm text-slate-600">
                  {item.brand} {item.model} - S/N: {item.serialNumber}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Euro className="h-4 w-4 text-orange-600" />
                <span className="font-bold text-orange-900">
                  {item.replacementCost}€
                </span>
              </div>
            </div>
          ))}
          
          <div className="border-t border-orange-200 pt-3 mt-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-lg text-orange-900">
                Total à rembourser :
              </span>
              <div className="flex items-center gap-2">
                <Euro className="h-5 w-5 text-orange-600" />
                <span className="font-bold text-xl text-orange-900">
                  {totalCost}€
                </span>
              </div>
            </div>
          </div>
          
          <div className="bg-orange-100 p-3 rounded-lg border border-orange-200 mt-3">
            <p className="text-xs text-orange-800">
              <strong>Information :</strong> Ces frais de remplacement sont automatiquement calculés 
              selon les tarifs en vigueur. Le montant sera déduit du dernier salaire ou facturé séparément.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MaterialCostCalculator;