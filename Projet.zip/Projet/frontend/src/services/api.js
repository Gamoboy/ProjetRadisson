import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Employee API functions
export const employeeAPI = {
  // Get all employees
  getAll: async (status = null) => {
    const params = status ? { status } : {};
    const response = await apiClient.get('/employees', { params });
    return response.data;
  },

  // Get employee by ID
  getById: async (id) => {
    const response = await apiClient.get(`/employees/${id}`);
    return response.data;
  },

  // Create new employee
  create: async (employeeData) => {
    const response = await apiClient.post('/employees', employeeData);
    return response.data;
  },

  // Update employee
  update: async (id, employeeData) => {
    const response = await apiClient.put(`/employees/${id}`, employeeData);
    return response.data;
  },

  // Delete employee
  delete: async (id) => {
    const response = await apiClient.delete(`/employees/${id}`);
    return response.data;
  },

  // Add material to employee
  addMaterial: async (employeeId, materialData) => {
    const response = await apiClient.post(`/employees/${employeeId}/materials`, materialData);
    return response.data;
  }
};

// Material API functions
export const materialAPI = {
  // Update material (mark as returned, etc.)
  update: async (materialId, updateData) => {
    const response = await apiClient.put(`/materials/${materialId}`, updateData);
    return response.data;
  }
};

// Statistics API functions
export const statsAPI = {
  // Get dashboard statistics
  get: async () => {
    const response = await apiClient.get('/stats');
    return response.data;
  }
};

// Generic API helper
export const api = {
  // Test connection
  test: async () => {
    try {
      const response = await apiClient.get('/');
      return response.data;
    } catch (error) {
      console.error('API connection test failed:', error);
      throw error;
    }
  }
};

export default apiClient;