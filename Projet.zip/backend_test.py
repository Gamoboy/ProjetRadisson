#!/usr/bin/env python3
"""
Backend API Test Suite for Radisson Hotel Material Management System
Tests all CRUD operations, material management, and statistics endpoints
"""

import requests
import json
import os
from datetime import datetime
import time

# Get backend URL from environment
BACKEND_URL = "https://hotel-onboarding.preview.emergentagent.com/api"

class RadissonAPITester:
    def __init__(self):
        self.base_url = BACKEND_URL
        self.session = requests.Session()
        self.test_results = []
        self.created_employee_id = None
        self.created_material_id = None
        
    def log_test(self, test_name, success, message, response_data=None):
        """Log test results"""
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        if response_data:
            result["response"] = response_data
        self.test_results.append(result)
        
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} - {test_name}: {message}")
        
    def test_health_check(self):
        """Test API health check endpoint"""
        try:
            response = self.session.get(f"{self.base_url}/")
            if response.status_code == 200:
                data = response.json()
                if "message" in data and "Radisson Hotel" in data["message"]:
                    self.log_test("Health Check", True, "API is responding correctly", data)
                    return True
                else:
                    self.log_test("Health Check", False, f"Unexpected response format: {data}")
                    return False
            else:
                self.log_test("Health Check", False, f"HTTP {response.status_code}: {response.text}")
                return False
        except Exception as e:
            self.log_test("Health Check", False, f"Connection error: {str(e)}")
            return False
    
    def test_get_all_employees(self):
        """Test getting all employees"""
        try:
            response = self.session.get(f"{self.base_url}/employees")
            if response.status_code == 200:
                employees = response.json()
                if isinstance(employees, list):
                    self.log_test("Get All Employees", True, f"Retrieved {len(employees)} employees", {"count": len(employees)})
                    return employees
                else:
                    self.log_test("Get All Employees", False, "Response is not a list")
                    return None
            else:
                self.log_test("Get All Employees", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Get All Employees", False, f"Error: {str(e)}")
            return None
    
    def test_get_employee_by_id(self, employee_id):
        """Test getting a specific employee by ID"""
        try:
            response = self.session.get(f"{self.base_url}/employees/{employee_id}")
            if response.status_code == 200:
                employee = response.json()
                if "id" in employee and "firstName" in employee:
                    self.log_test("Get Employee by ID", True, f"Retrieved employee: {employee['firstName']} {employee['lastName']}")
                    return employee
                else:
                    self.log_test("Get Employee by ID", False, "Invalid employee data structure")
                    return None
            elif response.status_code == 404:
                self.log_test("Get Employee by ID", True, "Employee not found (404) - correct behavior for invalid ID")
                return None
            else:
                self.log_test("Get Employee by ID", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Get Employee by ID", False, f"Error: {str(e)}")
            return None
    
    def test_create_employee(self):
        """Test creating a new employee with materials"""
        try:
            new_employee = {
                "firstName": "Pierre",
                "lastName": "Dubois",
                "department": "Maintenance",
                "position": "Technicien",
                "status": "active",
                "materials": [
                    {
                        "type": "Ordinateur portable",
                        "brand": "Lenovo",
                        "model": "ThinkPad T14",
                        "serialNumber": "LN789456123",
                        "condition": "Neuf"
                    },
                    {
                        "type": "Téléphone",
                        "brand": "Yealink",
                        "model": "T46S",
                        "serialNumber": "YL123789456",
                        "condition": "Bon"
                    }
                ]
            }
            
            response = self.session.post(
                f"{self.base_url}/employees",
                json=new_employee,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 201:
                created_employee = response.json()
                if "id" in created_employee and "employeeId" in created_employee:
                    self.created_employee_id = created_employee["id"]
                    self.log_test("Create Employee", True, f"Created employee: {created_employee['employeeId']} with {len(created_employee.get('materials', []))} materials")
                    return created_employee
                else:
                    self.log_test("Create Employee", False, "Invalid response structure")
                    return None
            else:
                self.log_test("Create Employee", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Create Employee", False, f"Error: {str(e)}")
            return None
    
    def test_update_employee(self, employee_id):
        """Test updating an existing employee"""
        try:
            update_data = {
                "position": "Technicien Senior",
                "department": "Maintenance Technique"
            }
            
            response = self.session.put(
                f"{self.base_url}/employees/{employee_id}",
                json=update_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                updated_employee = response.json()
                if updated_employee.get("position") == "Technicien Senior":
                    self.log_test("Update Employee", True, f"Successfully updated employee position to: {updated_employee['position']}")
                    return updated_employee
                else:
                    self.log_test("Update Employee", False, "Update data not reflected in response")
                    return None
            elif response.status_code == 404:
                self.log_test("Update Employee", True, "Employee not found (404) - correct behavior for invalid ID")
                return None
            else:
                self.log_test("Update Employee", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Update Employee", False, f"Error: {str(e)}")
            return None
    
    def test_add_material_to_employee(self, employee_id):
        """Test adding material to an existing employee"""
        try:
            new_material = {
                "type": "Imprimante",
                "brand": "Canon",
                "model": "PIXMA TR4520",
                "serialNumber": "CN456123789",
                "condition": "Neuf"
            }
            
            response = self.session.post(
                f"{self.base_url}/employees/{employee_id}/materials",
                json=new_material,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                updated_employee = response.json()
                materials = updated_employee.get("materials", [])
                # Find the newly added material
                new_mat = next((m for m in materials if m.get("brand") == "Canon"), None)
                if new_mat:
                    self.created_material_id = new_mat.get("materialId")
                    self.log_test("Add Material", True, f"Added material: {new_material['type']} - {new_material['brand']} {new_material['model']}")
                    return updated_employee
                else:
                    self.log_test("Add Material", False, "Material not found in updated employee")
                    return None
            elif response.status_code == 404:
                self.log_test("Add Material", True, "Employee not found (404) - correct behavior for invalid ID")
                return None
            else:
                self.log_test("Add Material", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Add Material", False, f"Error: {str(e)}")
            return None
    
    def test_update_material(self, material_id):
        """Test updating material (mark as returned)"""
        try:
            update_data = {
                "returned": True,
                "condition": "Bon"
            }
            
            response = self.session.put(
                f"{self.base_url}/materials/{material_id}",
                json=update_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                updated_employee = response.json()
                # Find the updated material
                materials = updated_employee.get("materials", [])
                updated_mat = next((m for m in materials if m.get("materialId") == material_id), None)
                if updated_mat and updated_mat.get("returned") == True:
                    self.log_test("Update Material", True, f"Material {material_id} marked as returned")
                    return updated_employee
                else:
                    self.log_test("Update Material", False, "Material update not reflected")
                    return None
            elif response.status_code == 404:
                self.log_test("Update Material", True, "Material not found (404) - correct behavior for invalid ID")
                return None
            else:
                self.log_test("Update Material", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Update Material", False, f"Error: {str(e)}")
            return None
    
    def test_get_statistics(self):
        """Test getting dashboard statistics"""
        try:
            response = self.session.get(f"{self.base_url}/stats")
            if response.status_code == 200:
                stats = response.json()
                required_fields = ["activeEmployees", "totalMaterials", "pendingReturns", "departments"]
                if all(field in stats for field in required_fields):
                    self.log_test("Get Statistics", True, f"Stats: {stats['activeEmployees']} active employees, {stats['totalMaterials']} materials, {stats['pendingReturns']} pending returns, {stats['departments']} departments", stats)
                    return stats
                else:
                    self.log_test("Get Statistics", False, f"Missing required fields in stats response: {stats}")
                    return None
            else:
                self.log_test("Get Statistics", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Get Statistics", False, f"Error: {str(e)}")
            return None
    
    def test_delete_employee(self, employee_id):
        """Test deleting an employee"""
        try:
            response = self.session.delete(f"{self.base_url}/employees/{employee_id}")
            if response.status_code == 200:
                result = response.json()
                if "message" in result and "deleted" in result["message"].lower():
                    self.log_test("Delete Employee", True, f"Successfully deleted employee: {employee_id}")
                    return True
                else:
                    self.log_test("Delete Employee", False, f"Unexpected delete response: {result}")
                    return False
            elif response.status_code == 404:
                self.log_test("Delete Employee", True, "Employee not found (404) - correct behavior for invalid ID")
                return True
            else:
                self.log_test("Delete Employee", False, f"HTTP {response.status_code}: {response.text}")
                return False
        except Exception as e:
            self.log_test("Delete Employee", False, f"Error: {str(e)}")
            return False
    
    def test_error_handling(self):
        """Test error handling for invalid requests"""
        print("\n=== Testing Error Handling ===")
        
        # Test invalid employee ID
        self.test_get_employee_by_id("invalid_id_123")
        
        # Test creating employee with missing required fields
        try:
            invalid_employee = {"firstName": "Test"}  # Missing required lastName
            response = self.session.post(
                f"{self.base_url}/employees",
                json=invalid_employee,
                headers={"Content-Type": "application/json"}
            )
            if response.status_code in [400, 422]:  # Validation error expected
                self.log_test("Invalid Employee Creation", True, f"Correctly rejected invalid employee data (HTTP {response.status_code})")
            else:
                self.log_test("Invalid Employee Creation", False, f"Should have rejected invalid data but got HTTP {response.status_code}")
        except Exception as e:
            self.log_test("Invalid Employee Creation", False, f"Error: {str(e)}")
    
    def run_all_tests(self):
        """Run all API tests in sequence"""
        print("🚀 Starting Radisson Hotel Material Management API Tests")
        print(f"Backend URL: {self.base_url}")
        print("=" * 60)
        
        # 1. Health Check
        print("\n=== Testing API Health ===")
        if not self.test_health_check():
            print("❌ API is not responding. Stopping tests.")
            return self.generate_report()
        
        # 2. Get all employees (initial data)
        print("\n=== Testing Employee Retrieval ===")
        employees = self.test_get_all_employees()
        
        # 3. Get specific employee
        if employees and len(employees) > 0:
            first_employee_id = employees[0].get("id") or employees[0].get("employeeId")
            self.test_get_employee_by_id(first_employee_id)
        
        # 4. Create new employee
        print("\n=== Testing Employee Creation ===")
        created_employee = self.test_create_employee()
        
        # 5. Update employee
        print("\n=== Testing Employee Updates ===")
        if self.created_employee_id:
            self.test_update_employee(self.created_employee_id)
        
        # 6. Add material to employee
        print("\n=== Testing Material Management ===")
        if self.created_employee_id:
            self.test_add_material_to_employee(self.created_employee_id)
        
        # 7. Update material
        if self.created_material_id:
            self.test_update_material(self.created_material_id)
        
        # 8. Get statistics
        print("\n=== Testing Statistics ===")
        self.test_get_statistics()
        
        # 9. Error handling tests
        self.test_error_handling()
        
        # 10. Cleanup - delete created employee
        print("\n=== Cleanup ===")
        if self.created_employee_id:
            self.test_delete_employee(self.created_employee_id)
        
        return self.generate_report()
    
    def generate_report(self):
        """Generate test report"""
        print("\n" + "=" * 60)
        print("📊 TEST RESULTS SUMMARY")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {failed_tests} ❌")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")
        
        print("\n" + "=" * 60)
        return {
            "total": total_tests,
            "passed": passed_tests,
            "failed": failed_tests,
            "success_rate": (passed_tests/total_tests)*100,
            "details": self.test_results
        }

if __name__ == "__main__":
    tester = RadissonAPITester()
    results = tester.run_all_tests()
    
    # Exit with error code if tests failed
    if results["failed"] > 0:
        exit(1)
    else:
        print("🎉 All tests passed!")
        exit(0)