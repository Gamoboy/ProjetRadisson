# Contrats API - Système de Gestion Matériel Radisson

## 1. API Contracts

### Employés
- **GET /api/employees** - Récupérer tous les employés
- **GET /api/employees/:id** - Récupérer un employé par ID
- **POST /api/employees** - Créer un nouvel employé
- **PUT /api/employees/:id** - Mettre à jour un employé
- **DELETE /api/employees/:id** - Supprimer un employé

### Matériel
- **POST /api/employees/:id/materials** - Ajouter du matériel à un employé
- **PUT /api/materials/:id** - Mettre à jour un matériel (restitution)
- **DELETE /api/materials/:id** - Supprimer un matériel

### Statistiques
- **GET /api/stats** - Obtenir les statistiques du dashboard

## 2. Modèles de données MongoDB

### Collection: employees
```json
{
  "_id": ObjectId,
  "employeeId": "EMP001",
  "firstName": "Marie",
  "lastName": "Dupont",
  "department": "Réception",
  "position": "Réceptionniste",
  "startDate": "2024-01-15",
  "endDate": null,
  "status": "active", // "active" | "departed"
  "materials": [
    {
      "materialId": "MAT001",
      "type": "Ordinateur portable",
      "brand": "Dell",
      "model": "Latitude 5520",
      "serialNumber": "DL123456789",
      "assignedDate": "2024-01-15",
      "condition": "Neuf",
      "returned": false,
      "returnedDate": null
    }
  ],
  "createdAt": Date,
  "updatedAt": Date
}
```

## 3. Données Mock à remplacer

### Dans `/src/mock.js`:
- `mockEmployees` -> Remplacer par API calls
- `getEmployeesFromStorage()` -> Remplacer par `GET /api/employees`
- `saveEmployeesToStorage()` -> Remplacer par API calls appropriées

## 4. Frontend-Backend Integration

### Fichiers à modifier:
1. **Dashboard.jsx**
   - Remplacer `getEmployeesFromStorage()` par `axios.get('/api/employees')`
   - Ajouter call API pour stats: `axios.get('/api/stats')`

2. **EmployeeForm.jsx** 
   - GET employee: `axios.get('/api/employees/:id')`
   - CREATE: `axios.post('/api/employees', employeeData)`
   - UPDATE: `axios.put('/api/employees/:id', employeeData)`

3. **MaterialManagement.jsx**
   - GET employees: `axios.get('/api/employees')`
   - ADD material: `axios.post('/api/employees/:id/materials', materialData)`
   - RETURN material: `axios.put('/api/materials/:id', {returned: true})`

4. **RestitutionProcess.jsx**
   - GET employees: `axios.get('/api/employees?status=departed')`
   - UPDATE material: `axios.put('/api/materials/:id', {returned: true})`

## 5. Implémentation Backend

### Étapes:
1. Créer modèles Pydantic pour Employee et Material
2. Implémenter endpoints CRUD pour employees
3. Implémenter endpoints pour gestion des matériaux  
4. Créer endpoint statistiques
5. Ajouter validation et gestion d'erreurs
6. Intégrer frontend avec backend APIs

### Configuration MongoDB:
- Base de données: `radisson_hotel`
- Collection: `employees`
- Index sur: `employeeId`, `status`, `department`