// Mock data for Radisson Hotel Material Management System

export const mockEmployees = [
  {
    id: "EMP001",
    firstName: "Marie",
    lastName: "Dupont", 
    department: "Réception",
    position: "Réceptionniste",
    startDate: "2024-01-15",
    endDate: null,
    status: "active",
    materials: [
      {
        id: "MAT001",
        type: "Ordinateur portable",
        brand: "Dell",
        model: "Latitude 5520",
        serialNumber: "DL123456789",
        assignedDate: "2024-01-15",
        condition: "Neuf",
        returned: false
      },
      {
        id: "MAT002", 
        type: "Téléphone",
        brand: "Cisco",
        model: "IP Phone 7841",
        serialNumber: "CS987654321",
        assignedDate: "2024-01-15",
        condition: "Bon",
        returned: false
      }
    ]
  },
  {
    id: "EMP002",
    firstName: "Jean", 
    lastName: "Martin",
    department: "IT",
    position: "Responsable Informatique",
    startDate: "2023-06-01",
    endDate: null,
    status: "active",
    materials: [
      {
        id: "MAT003",
        type: "Ordinateur portable",
        brand: "HP",
        model: "EliteBook 840",
        serialNumber: "HP456789123",
        assignedDate: "2023-06-01",
        condition: "Bon",
        returned: false
      }
    ]
  },
  {
    id: "EMP003",
    firstName: "Sophie",
    lastName: "Bernard",
    department: "Housekeeping",
    position: "Gouvernante",
    startDate: "2023-03-10",
    endDate: "2024-03-10",
    status: "departed",
    materials: [
      {
        id: "MAT004",
        type: "Tablette",
        brand: "Samsung",
        model: "Galaxy Tab A8",
        serialNumber: "SM789123456",
        assignedDate: "2023-03-10", 
        returnedDate: "2024-03-10",
        condition: "Bon",
        returned: true
      }
    ]
  }
];

export const mockMaterialTypes = [
  "Ordinateur portable",
  "Ordinateur de bureau", 
  "Écran",
  "Clavier",
  "Souris",
  "Téléphone",
  "Tablette",
  "Casque audio",
  "Webcam",
  "Imprimante",
  "Scanner",
  "Disque dur externe",
  "Câble réseau",
  "Adaptateur",
  "Badge Horaire",
  "Name Tag", 
  "Pins Yes I Can",
  "Carte Magnétique",
  "Uniforme - Chemise",
  "Uniforme - Teeshirt", 
  "Uniforme - Tablier",
  "Casier",
  "Cadenas",
  "Autre"
];

export const mockHRMaterials = [
  {
    name: "Badge Horaire",
    type: "badge",
    required: true,
    replacementCost: 10
  },
  {
    name: "Name Tag", 
    type: "badge",
    required: true,
    replacementCost: 10
  },
  {
    name: "Pins Yes I Can",
    type: "badge", 
    required: true,
    replacementCost: 5
  },
  {
    name: "Carte Magnétique",
    type: "access",
    required: true,
    replacementCost: 15
  },
  {
    name: "Uniforme - Chemise",
    type: "clothing",
    required: false,
    replacementCost: 25
  },
  {
    name: "Uniforme - Teeshirt",
    type: "clothing",
    required: false,
    replacementCost: 20
  },
  {
    name: "Uniforme - Tablier", 
    type: "clothing",
    required: false,
    replacementCost: 15
  },
  {
    name: "Casier",
    type: "storage",
    required: false,
    replacementCost: 0,
    hasNumber: true
  },
  {
    name: "Cadenas",
    type: "security",
    required: false,
    replacementCost: 5
  }
];

export const mockDepartments = [
  "Réception",
  "Housekeeping", 
  "Restaurant",
  "Bar",
  "Spa",
  "Maintenance",
  "IT",
  "RH",
  "Comptabilité",
  "Direction",
  "Sécurité",
  "Conciergerie"
];

export const mockConditions = [
  "Neuf",
  "Très bon",
  "Bon",
  "Correct", 
  "Usagé",
  "À réviser"
];

// Local storage helpers
export const getEmployeesFromStorage = () => {
  const stored = localStorage.getItem('radisson-employees');
  return stored ? JSON.parse(stored) : mockEmployees;
};

export const saveEmployeesToStorage = (employees) => {
  localStorage.setItem('radisson-employees', JSON.stringify(employees));
};