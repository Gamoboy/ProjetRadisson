import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { 
  Users, 
  Package, 
  AlertCircle, 
  TrendingUp,
  UserPlus,
  Search,
  Filter,
  Loader2
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { useToast } from "../hooks/use-toast";
import { employeeAPI, statsAPI } from "../services/api";

const Dashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [stats, setStats] = useState({
    activeEmployees: 0,
    totalMaterials: 0,
    pendingReturns: 0,
    departments: 0
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load employees and stats in parallel
      const [employeesData, statsData] = await Promise.all([
        employeeAPI.getAll(),
        statsAPI.get()
      ]);
      
      setEmployees(employeesData);
      setStats(statsData);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les données. Vérifiez votre connexion.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Filter employees based on search
  const filteredEmployees = employees.filter(emp =>
    emp.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const StatsCard = ({ title, value, icon: Icon, color, trend }) => (
    <Card className="relative overflow-hidden transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
        <Icon className={`h-5 w-5 ${color}`} />
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-slate-900">{value}</div>
        {trend && (
          <div className="flex items-center mt-2 text-xs text-slate-500">
            <TrendingUp className="h-3 w-3 mr-1" />
            {trend}
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Chargement des données...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Tableau de bord</h1>
          <p className="text-slate-600 mt-1">
            Gestion des fiches de matériel - Hôtel Radisson
          </p>
        </div>
        <Button asChild className="bg-blue-600 hover:bg-blue-700 transition-colors duration-200">
          <Link to="/employee/new">
            <UserPlus className="h-4 w-4 mr-2" />
            Nouvel employé
          </Link>
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Employés actifs"
          value={stats.activeEmployees}
          icon={Users}
          color="text-blue-600"
          trend="+2 ce mois"
        />
        <StatsCard
          title="Matériel assigné"
          value={stats.totalMaterials}
          icon={Package}
          color="text-green-600"
          trend={`${Math.round(stats.totalMaterials / stats.activeEmployees || 0)} par employé`}
        />
        <StatsCard
          title="Restitutions en attente"
          value={stats.pendingReturns}
          icon={AlertCircle}
          color="text-orange-600"
        />
        <StatsCard
          title="Départements"
          value={stats.departments}
          icon={TrendingUp}
          color="text-purple-600"
        />
      </div>

      {/* Recent Employees */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle className="text-xl text-slate-900">Employés récents</CardTitle>
            <div className="flex gap-2">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Rechercher un employé..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-2 font-medium text-slate-600">Employé</th>
                  <th className="text-left py-3 px-2 font-medium text-slate-600">Département</th>
                  <th className="text-left py-3 px-2 font-medium text-slate-600">Matériel</th>
                  <th className="text-left py-3 px-2 font-medium text-slate-600">Statut</th>
                  <th className="text-left py-3 px-2 font-medium text-slate-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.slice(0, 10).map((employee) => (
                  <tr 
                    key={employee.id} 
                    className="border-b border-slate-100 hover:bg-slate-50 transition-colors duration-150"
                  >
                    <td className="py-4 px-2">
                      <div>
                        <div className="font-medium text-slate-900">
                          {employee.firstName} {employee.lastName}
                        </div>
                        <div className="text-sm text-slate-500">{employee.position}</div>
                      </div>
                    </td>
                    <td className="py-4 px-2 text-slate-600">{employee.department}</td>
                    <td className="py-4 px-2">
                      <div className="text-sm">
                        {employee.materials?.filter(mat => !mat.returned).length || 0} équipement(s)
                      </div>
                    </td>
                    <td className="py-4 px-2">
                      <Badge 
                        variant={employee.status === "active" ? "default" : "secondary"}
                        className={employee.status === "active" ? "bg-green-100 text-green-800" : ""}
                      >
                        {employee.status === "active" ? "Actif" : "Parti"}
                      </Badge>
                    </td>
                    <td className="py-4 px-2">
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link to={`/employee/edit/${employee.id}`}>
                            Modifier
                          </Link>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {filteredEmployees.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              Aucun employé trouvé
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;