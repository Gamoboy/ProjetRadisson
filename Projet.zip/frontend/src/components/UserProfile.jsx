import React, { useState, useEffect } from "react";
import { User, Mail, Phone, Calendar, Badge, Building2, LogOut, Settings, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge as BadgeUI } from "./ui/badge";
import { Separator } from "./ui/separator";

const UserProfile = () => {
  const [currentUser, setCurrentUser] = useState({
    firstName: "Marie",
    lastName: "Dupont",
    email: "marie.dupont@radisson.com",
    phone: "+33 1 23 45 67 89",
    department: "Ressources Humaines",
    position: "Responsable RH",
    employeeId: "EMP001",
    startDate: "2023-01-15",
    role: "Administrator",
    permissions: ["manage_employees", "manage_materials", "hr_signatures"]
  });

  const [recentActivity, setRecentActivity] = useState([
    {
      id: 1,
      action: "Création employé",
      target: "Pierre Durand - IT",
      timestamp: "Il y a 2 heures",
      type: "create"
    },
    {
      id: 2,
      action: "Restitution matériel",
      target: "Sophie Bernard - Ordinateur portable",
      timestamp: "Il y a 5 heures",
      type: "return"
    },
    {
      id: 3,
      action: "Attribution matériel",
      target: "Jean Martin - Téléphone IP",
      timestamp: "Hier",
      type: "assign"
    },
    {
      id: 4,
      action: "Signature RH",
      target: "Fiche restitution - Alice Robert",
      timestamp: "Il y a 2 jours",
      type: "signature"
    }
  ]);

  const getInitials = (firstName, lastName) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`;
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case "create":
        return <User className="h-4 w-4 text-blue-600" />;
      case "return":
        return <LogOut className="h-4 w-4 text-green-600" />;
      case "assign":
        return <Badge className="h-4 w-4 text-orange-600" />;
      case "signature":
        return <Settings className="h-4 w-4 text-purple-600" />;
      default:
        return <Clock className="h-4 w-4 text-slate-600" />;
    }
  };

  const handleLogout = () => {
    // Implement logout logic
    console.log("Logout requested");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Profil utilisateur</h1>
        <p className="text-slate-600 mt-1">
          Gestion de votre compte et activité récente
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Information */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Avatar className="h-24 w-24">
                  <AvatarFallback className="text-2xl font-bold bg-blue-100 text-blue-600">
                    {getInitials(currentUser.firstName, currentUser.lastName)}
                  </AvatarFallback>
                </Avatar>
              </div>
              <CardTitle className="text-xl text-slate-900">
                {currentUser.firstName} {currentUser.lastName}
              </CardTitle>
              <p className="text-slate-600">{currentUser.position}</p>
              <div className="flex justify-center mt-2">
                <BadgeUI variant="secondary" className="bg-blue-100 text-blue-800">
                  {currentUser.role}
                </BadgeUI>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-600">{currentUser.email}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-600">{currentUser.phone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Building2 className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-600">{currentUser.department}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-600">{currentUser.employeeId}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-slate-400" />
                  <span className="text-sm text-slate-600">
                    Depuis le {new Date(currentUser.startDate).toLocaleDateString("fr-FR")}
                  </span>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <h4 className="font-medium text-slate-900">Permissions</h4>
                <div className="flex flex-wrap gap-1">
                  <BadgeUI variant="outline" className="text-xs">Gestion employés</BadgeUI>
                  <BadgeUI variant="outline" className="text-xs">Gestion matériel</BadgeUI>
                  <BadgeUI variant="outline" className="text-xs">Signatures RH</BadgeUI>
                </div>
              </div>

              <Separator />

              <Button 
                onClick={handleLogout}
                variant="outline" 
                className="w-full text-red-600 border-red-200 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Se déconnecter
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Activity and Settings */}
        <div className="lg:col-span-2 space-y-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-slate-900">Activité récente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center gap-4 p-3 bg-slate-50 rounded-lg">
                    <div className="flex-shrink-0">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-slate-900">{activity.action}</div>
                      <div className="text-sm text-slate-600">{activity.target}</div>
                    </div>
                    <div className="text-xs text-slate-500">
                      {activity.timestamp}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 pt-4 border-t border-slate-200">
                <Button variant="outline" className="w-full">
                  Voir toute l'activité
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-slate-900">Actions rapides</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="h-16 bg-blue-600 hover:bg-blue-700" onClick={() => window.location.href = '/employee/new'}>
                  <div className="text-center">
                    <User className="h-6 w-6 mx-auto mb-1" />
                    <div className="text-sm font-medium">Nouvel employé</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-16" onClick={() => window.location.href = '/material-management'}>
                  <div className="text-center">
                    <Badge className="h-6 w-6 mx-auto mb-1" />
                    <div className="text-sm font-medium">Gestion matériel</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-16" onClick={() => window.location.href = '/restitution'}>
                  <div className="text-center">
                    <LogOut className="h-6 w-6 mx-auto mb-1" />
                    <div className="text-sm font-medium">Restitutions</div>
                  </div>
                </Button>
                
                <Button variant="outline" className="h-16">
                  <div className="text-center">
                    <Settings className="h-6 w-6 mx-auto mb-1" />
                    <div className="text-sm font-medium">Paramètres</div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* System Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-slate-900">Informations système</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="p-3 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">127</div>
                  <div className="text-xs text-slate-600">Employés gérés</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">89</div>
                  <div className="text-xs text-slate-600">Matériels actifs</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">12</div>
                  <div className="text-xs text-slate-600">En attente</div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">15</div>
                  <div className="text-xs text-slate-600">Départements</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;