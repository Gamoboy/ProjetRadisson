import React, { useState } from "react";
import { FileCheck, User, Calendar, PenTool } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { mockHRMaterials } from "../mock";

const HRSignatureSection = ({ 
  employee, 
  materials = [], 
  mode = "reception", // "reception" or "restitution"
  onSignatureComplete 
}) => {
  const [hrSignatures, setHrSignatures] = useState({
    hrName: "",
    hrDate: new Date().toISOString().split('T')[0],
    hrSignature: "",
    employeeSignature: "",
    employeeDate: new Date().toISOString().split('T')[0]
  });

  const [materialStatus, setMaterialStatus] = useState(
    mockHRMaterials.reduce((acc, item) => {
      acc[item.name] = {
        provided: false,
        returned: false,
        casierNumber: "",
        condition: "Bon",
        notes: ""
      };
      return acc;
    }, {})
  );

  const handleMaterialStatusChange = (materialName, field, value) => {
    setMaterialStatus(prev => ({
      ...prev,
      [materialName]: {
        ...prev[materialName],
        [field]: value
      }
    }));
  };

  const handleSignatureChange = (field, value) => {
    setHrSignatures(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleComplete = () => {
    if (onSignatureComplete) {
      onSignatureComplete({
        signatures: hrSignatures,
        materialStatus: materialStatus
      });
    }
  };

  const isFormValid = () => {
    return hrSignatures.hrName && 
           hrSignatures.hrSignature && 
           hrSignatures.employeeSignature;
  };

  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardHeader>
        <CardTitle className="text-xl text-blue-900 flex items-center gap-2">
          <FileCheck className="h-6 w-6" />
          {mode === "reception" ? "Attestation de remise du matériel - Section RH" : "Attestation de restitution du matériel - Section RH"}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Employee Information */}
        <div className="bg-white p-4 rounded-lg border border-blue-200">
          <h3 className="font-semibold text-blue-900 mb-3">Informations employé</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Nom complet :</span> {employee?.firstName} {employee?.lastName}
            </div>
            <div>
              <span className="font-medium">Département :</span> {employee?.department}
            </div>
            <div>
              <span className="font-medium">Poste :</span> {employee?.position}
            </div>
            <div>
              <span className="font-medium">Date d'arrivée :</span> {employee?.startDate ? new Date(employee.startDate).toLocaleDateString("fr-FR") : ""}
            </div>
          </div>
        </div>

        {/* Material Checklist */}
        <div className="bg-white p-4 rounded-lg border border-blue-200">
          <h3 className="font-semibold text-blue-900 mb-4">
            {mode === "reception" ? "Matériel remis" : "Matériel restitué"}
          </h3>
          
          <div className="space-y-3">
            <div className="grid grid-cols-6 gap-2 text-xs font-medium text-slate-600 pb-2 border-b">
              <div>Désignation</div>
              <div className="text-center">{mode === "reception" ? "Remis" : "Restitué"}</div>
              <div className="text-center">Date</div>
              <div>État</div>
              <div>N° Casier</div>
              <div>Observations</div>
            </div>
            
            {mockHRMaterials.map((item, index) => (
              <div key={index} className="grid grid-cols-6 gap-2 items-center py-2 border-b border-slate-100">
                <div className="text-sm font-medium text-slate-900">
                  {item.name}
                  {item.required && <Badge variant="secondary" className="ml-1 text-xs">Requis</Badge>}
                </div>
                
                <div className="flex justify-center">
                  <input
                    type="checkbox"
                    checked={mode === "reception" ? materialStatus[item.name]?.provided : materialStatus[item.name]?.returned}
                    onChange={(e) => handleMaterialStatusChange(
                      item.name, 
                      mode === "reception" ? "provided" : "returned", 
                      e.target.checked
                    )}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <Input
                    type="date"
                    value={hrSignatures.hrDate}
                    onChange={(e) => handleSignatureChange("hrDate", e.target.value)}
                    className="text-xs h-8"
                  />
                </div>
                
                <div>
                  <select
                    value={materialStatus[item.name]?.condition || "Bon"}
                    onChange={(e) => handleMaterialStatusChange(item.name, "condition", e.target.value)}
                    className="text-xs h-8 w-full border border-slate-300 rounded px-2"
                  >
                    <option value="Neuf">Neuf</option>
                    <option value="Très bon">Très bon</option>
                    <option value="Bon">Bon</option>
                    <option value="Correct">Correct</option>
                    <option value="Usagé">Usagé</option>
                    <option value="Endommagé">Endommagé</option>
                    <option value="Perdu">Perdu</option>
                  </select>
                </div>
                
                <div>
                  {item.hasNumber ? (
                    <Input
                      placeholder="N°"
                      value={materialStatus[item.name]?.casierNumber || ""}
                      onChange={(e) => handleMaterialStatusChange(item.name, "casierNumber", e.target.value)}
                      className="text-xs h-8"
                    />
                  ) : (
                    <span className="text-xs text-slate-400">-</span>
                  )}
                </div>
                
                <div>
                  <Input
                    placeholder="Notes"
                    value={materialStatus[item.name]?.notes || ""}
                    onChange={(e) => handleMaterialStatusChange(item.name, "notes", e.target.value)}
                    className="text-xs h-8"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* HR Signature */}
          <div className="bg-white p-4 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-blue-900 mb-4 flex items-center gap-2">
              <User className="h-4 w-4" />
              Signature Service RH
            </h3>
            <div className="space-y-3">
              <div>
                <Label htmlFor="hrName">Nom et prénom *</Label>
                <Input
                  id="hrName"
                  value={hrSignatures.hrName}
                  onChange={(e) => handleSignatureChange("hrName", e.target.value)}
                  placeholder="Nom complet du responsable RH"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="hrDate">Date</Label>
                <Input
                  id="hrDate"
                  type="date"
                  value={hrSignatures.hrDate}
                  onChange={(e) => handleSignatureChange("hrDate", e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="hrSignature">Signature *</Label>
                <div className="mt-1 border-2 border-dashed border-blue-300 rounded-lg p-4 bg-blue-25">
                  <Input
                    id="hrSignature"
                    value={hrSignatures.hrSignature}
                    onChange={(e) => handleSignatureChange("hrSignature", e.target.value)}
                    placeholder="Tapez votre nom pour signer"
                    className="text-center font-serif text-lg"
                  />
                  <p className="text-xs text-blue-600 text-center mt-1">
                    Signature numérique
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Employee Signature */}
          <div className="bg-white p-4 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-blue-900 mb-4 flex items-center gap-2">
              <PenTool className="h-4 w-4" />
              Signature Employé
            </h3>
            <div className="space-y-3">
              <div>
                <Label>Nom et prénom</Label>
                <Input
                  value={`${employee?.firstName || ""} ${employee?.lastName || ""}`}
                  disabled
                  className="mt-1 bg-slate-100"
                />
              </div>
              <div>
                <Label htmlFor="employeeDate">Date</Label>
                <Input
                  id="employeeDate"
                  type="date"
                  value={hrSignatures.employeeDate}
                  onChange={(e) => handleSignatureChange("employeeDate", e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="employeeSignature">Signature *</Label>
                <div className="mt-1 border-2 border-dashed border-blue-300 rounded-lg p-4 bg-blue-25">
                  <Input
                    id="employeeSignature"
                    value={hrSignatures.employeeSignature}
                    onChange={(e) => handleSignatureChange("employeeSignature", e.target.value)}
                    placeholder="L'employé tape son nom pour signer"
                    className="text-center font-serif text-lg"
                  />
                  <p className="text-xs text-blue-600 text-center mt-1">
                    Signature numérique employé
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Engagement Text */}
        <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
          <h4 className="font-semibold text-amber-900 mb-2">Engagement de l'employé :</h4>
          <p className="text-sm text-amber-800">
            {mode === "reception" 
              ? "Je reconnais avoir reçu en bon état le matériel mentionné ci-dessus et m'engage à en prendre soin et à le restituer en fin de contrat dans le même état, usure normale exceptée."
              : "Je confirme avoir restitué l'intégralité du matériel mentionné ci-dessus au service RH de l'établissement dans l'état indiqué."
            }
          </p>
        </div>

        {/* Complete Button */}
        <div className="flex justify-end">
          <Button
            onClick={handleComplete}
            disabled={!isFormValid()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <FileCheck className="h-4 w-4 mr-2" />
            {mode === "reception" ? "Finaliser la remise" : "Finaliser la restitution"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default HRSignatureSection;