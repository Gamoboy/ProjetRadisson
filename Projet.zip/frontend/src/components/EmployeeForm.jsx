import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Plus, Trash2, Save, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { useToast } from "../hooks/use-toast";
import { employeeAPI } from "../services/api";
import { mockDepartments, mockMaterialTypes, mockConditions } from "../mock";
import HRSignatureSection from "./HRSignatureSection";

const EmployeeForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { toast } = useToast();
  const isEdit = Boolean(id);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    department: "",
    position: "",
    startDate: new Date().toISOString().split('T')[0],
    endDate: "",
    status: "active"
  });

  const [materials, setMaterials] = useState([]);
  const [newMaterial, setNewMaterial] = useState({
    type: "",
    brand: "",
    model: "",
    serialNumber: "",
    condition: "Neuf"
  });

  useEffect(() => {
    if (isEdit) {
      loadEmployee();
    }
  }, [id, isEdit]);

  const loadEmployee = async () => {
    setLoading(true);
    try {
      const employee = await employeeAPI.getById(id);
      setFormData({
        firstName: employee.firstName,
        lastName: employee.lastName,
        department: employee.department,
        position: employee.position || "",
        startDate: employee.startDate,
        endDate: employee.endDate || "",
        status: employee.status
      });
      setMaterials(employee.materials || []);
    } catch (error) {
      console.error('Error loading employee:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les données de l'employé",
        variant: "destructive"
      });
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleMaterialChange = (field, value) => {
    setNewMaterial(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addMaterial = () => {
    if (!newMaterial.type || !newMaterial.brand || !newMaterial.serialNumber) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires du matériel",
        variant: "destructive"
      });
      return;
    }

    const material = {
      materialId: `MAT${Date.now()}`, // Temporary ID for frontend
      ...newMaterial,
      assignedDate: new Date().toISOString().split('T')[0],
      returned: false
    };

    setMaterials(prev => [...prev, material]);
    setNewMaterial({
      type: "",
      brand: "",
      model: "",
      serialNumber: "",
      condition: "Neuf"
    });

    toast({
      title: "Matériel ajouté",
      description: "Le matériel a été ajouté avec succès"
    });
  };

  const removeMaterial = (materialIndex) => {
    setMaterials(prev => prev.filter((_, index) => index !== materialIndex));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.firstName || !formData.lastName || !formData.department) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      const employeeData = {
        ...formData,
        materials
      };

      if (isEdit) {
        await employeeAPI.update(id, employeeData);
        toast({
          title: "Succès",
          description: "Employé modifié avec succès"
        });
      } else {
        await employeeAPI.create(employeeData);
        toast({
          title: "Succès",
          description: "Employé créé avec succès"
        });
      }

      navigate("/");
    } catch (error) {
      console.error('Error saving employee:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la sauvegarde. Veuillez réessayer.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2 text-slate-600">Chargement...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate("/")}
          className="hover:bg-slate-100"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">
            {isEdit ? "Modifier l'employé" : "Nouvel employé"}
          </h1>
          <p className="text-slate-600 mt-1">
            {isEdit ? "Mise à jour des informations" : "Fiche de remise du matériel"}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Employee Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl text-slate-900">Informations employé</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Prénom *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  placeholder="Prénom de l'employé"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Nom *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  placeholder="Nom de l'employé"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="department">Département *</Label>
                <Select 
                  value={formData.department} 
                  onValueChange={(value) => handleInputChange("department", value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Sélectionner un département" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockDepartments.map(dept => (
                      <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="position">Poste</Label>
                <Input
                  id="position"
                  value={formData.position}
                  onChange={(e) => handleInputChange("position", e.target.value)}
                  placeholder="Poste de l'employé"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="startDate">Date d'arrivée</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => handleInputChange("startDate", e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="endDate">Date de départ (si applicable)</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => handleInputChange("endDate", e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Material Management */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl text-slate-900">Matériel informatique</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Add New Material */}
            <div className="p-4 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
              <h3 className="font-medium text-slate-900 mb-3">Ajouter du matériel</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
                <Select 
                  value={newMaterial.type} 
                  onValueChange={(value) => handleMaterialChange("type", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockMaterialTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Input
                  value={newMaterial.brand}
                  onChange={(e) => handleMaterialChange("brand", e.target.value)}
                  placeholder="Marque"
                />
                
                <Input
                  value={newMaterial.model}
                  onChange={(e) => handleMaterialChange("model", e.target.value)}
                  placeholder="Modèle"
                />
                
                <Input
                  value={newMaterial.serialNumber}
                  onChange={(e) => handleMaterialChange("serialNumber", e.target.value)}
                  placeholder="N° série"
                />
                
                <div className="flex gap-2">
                  <Select 
                    value={newMaterial.condition} 
                    onValueChange={(value) => handleMaterialChange("condition", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {mockConditions.map(condition => (
                        <SelectItem key={condition} value={condition}>{condition}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Button 
                    type="button" 
                    onClick={addMaterial}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Materials List */}
            {materials.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-medium text-slate-900">Matériel assigné</h3>
                {materials.map((material, index) => (
                  <div 
                    key={material.materialId || index}
                    className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-slate-900">{material.type}</span>
                        <Badge variant="secondary">{material.condition}</Badge>
                      </div>
                      <div className="text-sm text-slate-600">
                        {material.brand} {material.model} - {material.serialNumber}
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeMaterial(index)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* HR Signature Section - Only for new employees */}
        {!isEdit && (
          <HRSignatureSection 
            employee={formData}
            materials={materials}
            mode="reception"
            onSignatureComplete={(data) => {
              // Store HR signature data for submission
              console.log("HR Signature data:", data);
            }}
          />
        )}

        {/* Terms and Conditions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl text-slate-900">Conditions d'utilisation du matériel</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <h3 className="font-semibold text-amber-900 mb-3">Engagement de l'employé :</h3>
              <div className="text-sm text-amber-800 space-y-2">
                <p>
                  <strong>Maintenance :</strong> Vous êtes tenu de maintenir ces outils de travail dans un parfait état de fonctionnement.
                </p>
                <p>
                  <strong>Restitution :</strong> Par ce présent contrat, vous vous engagez à restituer l'intégralité du matériel ainsi confié au moment 
                  de la rupture de votre contrat et ce, quel que soit le motif de cette rupture.
                </p>
                <p>
                  <strong>Badges et frais de remplacement :</strong> En cas de perte de badges remis gratuitement, la personne concernée pourra bénéficier des badges de 
                  remplacement et la société pourra lui demander de rembourser ou de prendre en charge les éventuels 
                  frais de remplacement.
                </p>
              </div>
            </div>
            
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-medium text-slate-900 mb-2">Tarifs de remplacement :</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div className="flex justify-between">
                  <span>Cadenas :</span>
                  <span className="font-medium">5€</span>
                </div>
                <div className="flex justify-between">
                  <span>Pins Yes I Can :</span>
                  <span className="font-medium">5€</span>
                </div>
                <div className="flex justify-between">
                  <span>Name Tag :</span>
                  <span className="font-medium">10€</span>
                </div>
                <div className="flex justify-between">
                  <span>Badge Horaire :</span>
                  <span className="font-medium">10€</span>
                </div>
              </div>
            </div>
            
            {!isEdit && (
              <div className="flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="acceptTerms" 
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  required
                />
                <Label htmlFor="acceptTerms" className="text-sm">
                  J'accepte les conditions d'utilisation du matériel et m'engage à respecter les obligations énoncées ci-dessus
                </Label>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className="flex justify-end">
          <Button 
            type="submit" 
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 transition-colors duration-200"
          >
            {saving ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {saving ? "Sauvegarde..." : (isEdit ? "Mettre à jour" : "Créer la fiche")}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default EmployeeForm;