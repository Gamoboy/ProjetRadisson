import React from "react";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import EmployeeForm from "./components/EmployeeForm";
import MaterialManagement from "./components/MaterialManagement";
import RestitutionProcess from "./components/RestitutionProcess";
import UserProfile from "./components/UserProfile";
import EmployeeFlow from "./components/EmployeeFlow";
import Layout from "./components/Layout";
import { Toaster } from "./components/ui/toaster";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/employee/new" element={<EmployeeForm />} />
            <Route path="/employee/edit/:id" element={<EmployeeForm />} />
            <Route path="/employee-flow" element={<EmployeeFlow />} />
            <Route path="/material-management" element={<MaterialManagement />} />
            <Route path="/restitution" element={<RestitutionProcess />} />
            <Route path="/profile" element={<UserProfile />} />
          </Routes>
        </Layout>
      </BrowserRouter>
      <Toaster />
    </div>
  );
}

export default App;