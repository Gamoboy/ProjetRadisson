from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from bson import ObjectId

class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid objectid")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, field_schema):
        field_schema.update(type="string")
        return field_schema

class Material(BaseModel):
    materialId: str = Field(default_factory=lambda: f"MAT{int(datetime.now().timestamp())}")
    type: str
    brand: str
    model: str
    serialNumber: str
    assignedDate: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    condition: str = "Neuf"
    returned: bool = False
    returnedDate: Optional[str] = None

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class Employee(BaseModel):
    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    employeeId: str = Field(default_factory=lambda: f"EMP{int(datetime.now().timestamp())}")
    firstName: str
    lastName: str
    department: str
    position: str = ""
    startDate: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    endDate: Optional[str] = None
    status: str = "active"
    materials: List[Material] = []
    createdAt: datetime = Field(default_factory=datetime.now)
    updatedAt: datetime = Field(default_factory=datetime.now)

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class EmployeeCreate(BaseModel):
    firstName: str
    lastName: str
    department: str
    position: str = ""
    startDate: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    endDate: Optional[str] = None
    status: str = "active"
    materials: List[Material] = []

class EmployeeUpdate(BaseModel):
    firstName: Optional[str] = None
    lastName: Optional[str] = None
    department: Optional[str] = None
    position: Optional[str] = None
    startDate: Optional[str] = None
    endDate: Optional[str] = None
    status: Optional[str] = None
    materials: Optional[List[Material]] = None
    updatedAt: datetime = Field(default_factory=datetime.now)

class MaterialUpdate(BaseModel):
    returned: Optional[bool] = None
    returnedDate: Optional[str] = None
    condition: Optional[str] = None

class Stats(BaseModel):
    activeEmployees: int
    totalMaterials: int
    pendingReturns: int
    departments: int