from fastapi import FastAPI, APIRouter, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from models import Employee, EmployeeCreate, EmployeeUpdate, Material, MaterialUpdate, Stats
from typing import List, Optional
import os
import logging
from datetime import datetime
from bson import ObjectId
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client.radisson_hotel

# Create the main app
app = FastAPI(title="Radisson Hotel Material Management API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Helper function to convert ObjectId to string
def employee_helper(employee) -> dict:
    if employee:
        employee["id"] = str(employee["_id"])
        # Convert any ObjectId fields to strings
        if "_id" in employee:
            del employee["_id"]
        return employee
    return None

# Initialize database with sample data
async def init_db():
    """Initialize database with sample data if empty"""
    count = await db.employees.count_documents({})
    if count == 0:
        sample_employees = [
            {
                "employeeId": "EMP001",
                "firstName": "Marie",
                "lastName": "Dupont",
                "department": "Réception",
                "position": "Réceptionniste",
                "startDate": "2024-01-15",
                "endDate": None,
                "status": "active",
                "materials": [
                    {
                        "materialId": "MAT001",
                        "type": "Ordinateur portable",
                        "brand": "Dell",
                        "model": "Latitude 5520",
                        "serialNumber": "DL123456789",
                        "assignedDate": "2024-01-15",
                        "condition": "Neuf",
                        "returned": False,
                        "returnedDate": None
                    },
                    {
                        "materialId": "MAT002",
                        "type": "Téléphone",
                        "brand": "Cisco",
                        "model": "IP Phone 7841",
                        "serialNumber": "CS987654321",
                        "assignedDate": "2024-01-15",
                        "condition": "Bon",
                        "returned": False,
                        "returnedDate": None
                    }
                ],
                "createdAt": datetime.now(),
                "updatedAt": datetime.now()
            },
            {
                "employeeId": "EMP002",
                "firstName": "Jean",
                "lastName": "Martin",
                "department": "IT",
                "position": "Responsable Informatique",
                "startDate": "2023-06-01",
                "endDate": None,
                "status": "active",
                "materials": [
                    {
                        "materialId": "MAT003",
                        "type": "Ordinateur portable",
                        "brand": "HP",
                        "model": "EliteBook 840",
                        "serialNumber": "HP456789123",
                        "assignedDate": "2023-06-01",
                        "condition": "Bon",
                        "returned": False,
                        "returnedDate": None
                    }
                ],
                "createdAt": datetime.now(),
                "updatedAt": datetime.now()
            },
            {
                "employeeId": "EMP003",
                "firstName": "Sophie",
                "lastName": "Bernard",
                "department": "Housekeeping",
                "position": "Gouvernante",
                "startDate": "2023-03-10",
                "endDate": "2024-03-10",
                "status": "departed",
                "materials": [
                    {
                        "materialId": "MAT004",
                        "type": "Tablette",
                        "brand": "Samsung",
                        "model": "Galaxy Tab A8",
                        "serialNumber": "SM789123456",
                        "assignedDate": "2023-03-10",
                        "returnedDate": "2024-03-10",
                        "condition": "Bon",
                        "returned": True
                    }
                ],
                "createdAt": datetime.now(),
                "updatedAt": datetime.now()
            }
        ]
        
        result = await db.employees.insert_many(sample_employees)
        logger.info(f"Initialized database with {len(result.inserted_ids)} employees")

# API Routes

@api_router.get("/")
async def root():
    return {"message": "Radisson Hotel Material Management API"}

@api_router.get("/employees", response_model=List[dict])
async def get_all_employees(status: Optional[str] = None):
    """Get all employees, optionally filtered by status"""
    try:
        filter_query = {}
        if status:
            filter_query["status"] = status
            
        employees = await db.employees.find(filter_query).to_list(1000)
        return [employee_helper(employee) for employee in employees]
    except Exception as e:
        logger.error(f"Error fetching employees: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.get("/employees/{employee_id}", response_model=dict)
async def get_employee(employee_id: str):
    """Get a specific employee by ID"""
    try:
        # Try to find by MongoDB _id first, then by employeeId
        if ObjectId.is_valid(employee_id):
            employee = await db.employees.find_one({"_id": ObjectId(employee_id)})
        else:
            employee = await db.employees.find_one({"employeeId": employee_id})
            
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")
            
        return employee_helper(employee)
    except Exception as e:
        logger.error(f"Error fetching employee {employee_id}: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.post("/employees", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_employee(employee_data: EmployeeCreate):
    """Create a new employee"""
    try:
        # Convert to dict and add timestamps
        employee_dict = employee_data.dict()
        employee_dict["employeeId"] = f"EMP{int(datetime.now().timestamp())}"
        employee_dict["createdAt"] = datetime.now()
        employee_dict["updatedAt"] = datetime.now()
        
        result = await db.employees.insert_one(employee_dict)
        created_employee = await db.employees.find_one({"_id": result.inserted_id})
        
        logger.info(f"Created employee: {employee_dict['employeeId']}")
        return employee_helper(created_employee)
    except Exception as e:
        logger.error(f"Error creating employee: {e}")
        raise HTTPException(status_code=500, detail="Failed to create employee")

@api_router.put("/employees/{employee_id}", response_model=dict)
async def update_employee(employee_id: str, employee_data: EmployeeUpdate):
    """Update an existing employee"""
    try:
        # Prepare update data (exclude None values)
        update_data = {k: v for k, v in employee_data.dict().items() if v is not None}
        update_data["updatedAt"] = datetime.now()
        
        # Find and update employee
        if ObjectId.is_valid(employee_id):
            filter_query = {"_id": ObjectId(employee_id)}
        else:
            filter_query = {"employeeId": employee_id}
            
        result = await db.employees.update_one(filter_query, {"$set": update_data})
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Employee not found")
            
        updated_employee = await db.employees.find_one(filter_query)
        logger.info(f"Updated employee: {employee_id}")
        return employee_helper(updated_employee)
    except Exception as e:
        logger.error(f"Error updating employee {employee_id}: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail="Failed to update employee")

@api_router.delete("/employees/{employee_id}")
async def delete_employee(employee_id: str):
    """Delete an employee"""
    try:
        if ObjectId.is_valid(employee_id):
            filter_query = {"_id": ObjectId(employee_id)}
        else:
            filter_query = {"employeeId": employee_id}
            
        result = await db.employees.delete_one(filter_query)
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Employee not found")
            
        logger.info(f"Deleted employee: {employee_id}")
        return {"message": "Employee deleted successfully"}
    except Exception as e:
        logger.error(f"Error deleting employee {employee_id}: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail="Failed to delete employee")

@api_router.post("/employees/{employee_id}/materials", response_model=dict)
async def add_material_to_employee(employee_id: str, material: Material):
    """Add material to an employee"""
    try:
        # Find employee
        if ObjectId.is_valid(employee_id):
            filter_query = {"_id": ObjectId(employee_id)}
        else:
            filter_query = {"employeeId": employee_id}
            
        employee = await db.employees.find_one(filter_query)
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        # Add material
        material_dict = material.dict()
        material_dict["materialId"] = f"MAT{int(datetime.now().timestamp())}"
        
        result = await db.employees.update_one(
            filter_query,
            {
                "$push": {"materials": material_dict},
                "$set": {"updatedAt": datetime.now()}
            }
        )
        
        updated_employee = await db.employees.find_one(filter_query)
        logger.info(f"Added material to employee: {employee_id}")
        return employee_helper(updated_employee)
    except Exception as e:
        logger.error(f"Error adding material to employee {employee_id}: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail="Failed to add material")

@api_router.put("/materials/{material_id}", response_model=dict)
async def update_material(material_id: str, material_update: MaterialUpdate):
    """Update material (e.g., mark as returned)"""
    try:
        # Prepare update data
        update_data = {k: v for k, v in material_update.dict().items() if v is not None}
        
        # If marking as returned, set return date
        if update_data.get("returned") == True and not update_data.get("returnedDate"):
            update_data["returnedDate"] = datetime.now().strftime("%Y-%m-%d")
        
        # Find and update the material in the employee document
        result = await db.employees.update_one(
            {"materials.materialId": material_id},
            {
                "$set": {
                    f"materials.$.{key}": value for key, value in update_data.items()
                }
            }
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Material not found")
        
        # Find the employee with this material
        employee = await db.employees.find_one({"materials.materialId": material_id})
        logger.info(f"Updated material: {material_id}")
        return employee_helper(employee)
    except Exception as e:
        logger.error(f"Error updating material {material_id}: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail="Failed to update material")

@api_router.get("/stats", response_model=Stats)
async def get_stats():
    """Get dashboard statistics"""
    try:
        # Active employees
        active_employees = await db.employees.count_documents({"status": "active"})
        
        # Total materials (not returned)
        pipeline_materials = [
            {"$unwind": "$materials"},
            {"$match": {"materials.returned": False}},
            {"$count": "total"}
        ]
        materials_result = await db.employees.aggregate(pipeline_materials).to_list(1)
        total_materials = materials_result[0]["total"] if materials_result else 0
        
        # Pending returns (departed employees with unreturned materials)
        pipeline_pending = [
            {"$match": {"status": "departed"}},
            {"$unwind": "$materials"},
            {"$match": {"materials.returned": False}},
            {"$group": {"_id": "$_id"}},
            {"$count": "total"}
        ]
        pending_result = await db.employees.aggregate(pipeline_pending).to_list(1)
        pending_returns = pending_result[0]["total"] if pending_result else 0
        
        # Unique departments
        departments = await db.employees.distinct("department")
        
        return Stats(
            activeEmployees=active_employees,
            totalMaterials=total_materials,
            pendingReturns=pending_returns,
            departments=len(departments)
        )
    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch statistics")

# Include the router in the main app
app.include_router(api_router)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    await init_db()
    logger.info("Application started successfully")

@app.on_event("shutdown")
async def shutdown_event():
    client.close()
    logger.info("Application shutdown completed")